#include <p18f6722.h>
#include "globals.h"

void Light_Init(void) {
    TRISAbits.TRISA1 = 1; // RA1 input [cite: 41]
}

float Light_Read(void) {
    int res;
    
    ADCON0bits.CHS0 = 1; ADCON0bits.CHS1 = 0;
    ADCON0bits.CHS2 = 0; ADCON0bits.CHS3 = 0;
    
    ADCON0bits.GO = 1;
    while(ADCON0bits.GO);
    res = (ADRESH << 8) | ADRESL;
    return (res / 10.23); 
}