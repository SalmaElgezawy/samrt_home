#include <p18f6722.h>
#include "globals.h"

void Temp_Init(void) {
    TRISAbits.TRISA0 = 1; // RA0 input for LM35 [cite: 6, 41]
    ADCON1 = 0x0D;        // AN0, AN1 Analog [cite: 41]
    ADCON2 = 0x92;        // Right justified
    ADCON0 = 0x01;        // ADC ON
}

float Temp_Read(void) {
    int res;
    
    ADCON0bits.CHS0 = 0; ADCON0bits.CHS1 = 0;
    ADCON0bits.CHS2 = 0; ADCON0bits.CHS3 = 0;
    
    ADCON0bits.GO = 1;    
    while(ADCON0bits.GO); 
    res = (ADRESH << 8) | ADRESL;
    return (res * 0.48828); 
}