#ifndef GLOBALS_H
#define GLOBALS_H

// Temperature Module
void Temp_Init(void);
float Temp_Read(void);

// Light Module
void Light_Init(void);
float Light_Read(void);

// Display Module
void Display_Init(void);
void LCD_Print(const char *str);
void LCD_Write(unsigned char v, unsigned char d);
void Seg_Update(int v);

// Keypad & Security Functions
void Keypad_Init(void);
char Keypad_Read(void);
void Security_Check(void);

#endif